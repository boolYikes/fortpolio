#### Memo
```javascript
const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://localhost:27017/mydb';
mongoose.connect(MONGODB_URI)
.then(() => console.log('✅ MongoDB connected'))
.catch(err => console.error('❌ MongoDB connection error:', err));
```
`An event handler is a function!!!`

#### Code reference
[GPT chat record on MUI template](https://chatgpt.com/c/674178c7-a0bc-800d-9330-d2d005a782d9)

#### Prototyping
![blueprint](blueprint.png)
- dark background + an image of door opened with bright light

#### Contents Todos
- [ ] Title
- [ ] Bootcamp projects page
- [ ] Practical contributions page
- [ ] Side project page
- [ ] Other agenda on the nav menu